package com.sxt.web.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;

import com.google.gson.Gson;
import com.sxt.entity.UserDB;
import com.sxt.service.UserService;
import com.sxt.utils.MD5;
import com.sxt.utils.PageTool;
import com.sxt.utils.PaginationUtils;
import com.sxt.utils.ResBean;

/**
 * 用户
 * @author Administrator
 *
 */
@WebServlet("/register")
public class RegisterServlet extends BaseServlet {
	
    private static final long serialVersionUID = 1L;
    
    private UserService userService = new UserService();
    
    
    
    /**
     * 添加用户
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    public void register(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, IllegalAccessException, InvocationTargetException {
    	
    	UserDB userDB = new UserDB();
    	BeanUtils.populate(userDB, request.getParameterMap());
    	userDB.setTimes(0);
    	userDB.setPassword( MD5.valueOf(userDB.getPassword()));
    	userDB.setRole(1);
    	userDB.setLendNum(10);
    	userDB.setMaxNum(10);
    	System.out.println(userDB);
    	Integer isFlag = userService.isAccount(userDB.getAccount());
    	System.out.println(isFlag);
    	if(isFlag==0) {
    		userService.addUser(userDB);
        	request.getRequestDispatcher("register.jsp").forward(request, response);
    	}else {
    		PrintWriter pout =  response.getWriter();
    		pout.println("该账号已注册");
    	}
    	
    }
    

	

}
