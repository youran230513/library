package com.sxt.service;

import java.util.List;

import com.sxt.dao.UserDao;
import com.sxt.entity.UserDB;
import com.sxt.utils.PageTool;

/**
 * 用户业务层
 * @author Administrator
 *
 */
public class UserService {
	
	private UserDao userDao = new UserDao();

	/**
	 * 登陆
	 * @param account
	 * @param password
	 * @return
	 */
	public UserDB login(String account, String password) {
		return userDao.login(account, password);
	}
	
	/**
	 * 用户添加
	 * @param userDB
	 * @return
	 */
	public Integer addUser(UserDB userDB) {
		return userDao.addUser(userDB);
	}
	
	public PageTool<UserDB> list(String currentPage, String pageSize, Integer order){
		return userDao.list(currentPage, pageSize, order);
	}
	
	public List<UserDB> getList(UserDB userDB){
		return userDao.getList(userDB);
	}
	
	/**
	 * 管理员修改用户信息
	 * @param userDB
	 * @return
	 */
	public Integer updUser(UserDB userDB) {
		return userDao.updUser(userDB);		
	}
	
	/**
	 * 删除用户-物理删除
	 * @param uid
	 * @return
	 */
	public Integer delUser(Integer uid) {
		return userDao.delUser(uid);
	}
	public Integer isAccount(String account) {
		Integer isFlag = 0;
		List<UserDB> userDBs = userDao.isAccount(account);
		for (UserDB userDB : userDBs) {
			if(userDB.getAccount().equals(account)) {
				isFlag = 1;
			}else {
				isFlag = 0;
			}
		}
		// TODO Auto-generated method stub
		return isFlag;
		
	}
	
	
	public Integer updUserInfo(UserDB userDB) {
		// TODO Auto-generated method stub
		return userDao.updateUserInfo(userDB);
		
	}

	public Integer updUserPwd(UserDB userDB1) {
		// TODO Auto-generated method stub
		return userDao.updUserPwd(userDB1);
	}
}
