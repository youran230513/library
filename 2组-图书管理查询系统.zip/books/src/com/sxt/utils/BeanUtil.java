package com.sxt.utils;

import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;

public class BeanUtil {

	// 通过反射把request中的参数设置到对应的实体类对象中
	public static <T> T getBean(HttpServletRequest request, Class<T> clazz) {
		T bean = null;
		try {
			bean = clazz.newInstance();
			// 获得所有的参数名
			Enumeration<String> enums = request.getParameterNames();
			// 遍历所有的参数名
			while (enums.hasMoreElements()) {
				String name = enums.nextElement();
				// 通过参数名获得参数值
				String value = request.getParameter(name);
				// 构建方法名
				String methodName = "set" + name.substring(0, 1).toUpperCase() + name.substring(1);
				// 获得类中所有的方法
				Method[] methods = clazz.getMethods();
				// 遍历所有的方法，找到对应的set方法
				for (Method method : methods) {
					// 判断是否是对应的set方法
					if (method.getName().equals(methodName)) {
						// 获得方法的参数类型
						Class<?>[] paramTypes = method.getParameterTypes();
						// 判断参数类型
						if (paramTypes[0].getName().equals("int")) {
							if (value != null && !value.trim().equals("")) {
								method.invoke(bean, Integer.parseInt(value));
							}
						} else if (paramTypes[0].getName().equals("double")) {
							if (value != null && !value.trim().equals("")) {
								method.invoke(bean, Double.parseDouble(value));
							}
						} else if (paramTypes[0].getName().equals("java.util.Date")) {
							if (value != null && !value.trim().equals("")) {
								method.invoke(bean, DateUtils.parseDate(value));
							}
						} else {
							method.invoke(bean, value);
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bean;
	}

	// 另一个简化版本
	public static <T> T getBean2(HttpServletRequest request, Class<T> clazz) {
		T bean = null;
		try {
			bean = clazz.newInstance();
			// 获得所有的参数和值
			Map<String, String[]> map = request.getParameterMap();
			// 使用BeanUtils工具类设置值
			BeanUtils.populate(bean, map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bean;
	}

}