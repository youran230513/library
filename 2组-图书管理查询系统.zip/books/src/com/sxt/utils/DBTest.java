package com.sxt.utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBTest {
    public static void main(String[] args) {
        System.out.println("Testing database connection...");
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            if (conn != null) {
                System.out.println("Database connection successful!");
                
                stmt = conn.createStatement();
                rs = stmt.executeQuery("SELECT COUNT(*) AS count FROM t_book");
                if (rs.next()) {
                    int count = rs.getInt("count");
                    System.out.println("Book count: " + count);
                }
                
                rs = stmt.executeQuery("SELECT account, name FROM t_user LIMIT 2");
                System.out.println("User info:");
                while (rs.next()) {
                    System.out.println("Account: " + rs.getString("account") + ", Name: " + rs.getString("name"));
                }
            } else {
                System.out.println("Database connection failed!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(rs);
            DBUtil.close(stmt);
            DBUtil.close(conn);
        }
    }
}