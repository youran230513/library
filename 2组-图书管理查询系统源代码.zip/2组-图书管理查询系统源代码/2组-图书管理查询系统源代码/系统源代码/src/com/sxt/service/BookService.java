package com.sxt.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import com.sxt.dao.BookDao;
import com.sxt.dao.HistoryDao;
import com.sxt.dao.UserDao;
import com.sxt.entity.BookDB;
import com.sxt.entity.HistoryDB;
import com.sxt.entity.UserDB;
import com.sxt.utils.C3p0Tool;
import com.sxt.utils.DateUtils;
import com.sxt.utils.MyException;
import com.sxt.utils.PageTool;

public class BookService {

	private BookDao bookDao = new BookDao();
	
	private HistoryDao historyDao = new HistoryDao();
	
	private UserDao userDao = new UserDao();
	
	public PageTool<BookDB> listByPage(String currentPage, String pageSize, String word, Integer order){
		return bookDao.list(currentPage, pageSize, word, order);
	}
	
	public List<BookDB> list(String bookName){
		return bookDao.list(bookName, null);
	}
	
	public Integer addBook(BookDB bookDB) {
		return bookDao.addBook(bookDB);
	}
	
	public Integer updBook(BookDB bookDB) {
		return bookDao.updBook(bookDB);
	}
	
	public int delBook(String bid) {
		return bookDao.delBook(bid);
	}

	/**
	 * 用户借阅图书 【已修复：适配LocalDateTime】
	 * @param userDB
	 * @param bid
	 */
	public void borrowBook(UserDB userDB, String bid) {
		Connection conn = C3p0Tool.getConnection();
		try {
			conn.setAutoCommit(false);
			List<BookDB> list = bookDao.list(null, bid);
			BookDB bookDB = list.get(0);
			userDB = userDao.getList(userDB).get(0);
			
			HistoryDB historyDB = new HistoryDB();
			historyDB.setUid(userDB.getUid());
			historyDB.setName(userDB.getName());
			historyDB.setAccount(userDB.getAccount());
			historyDB.setBid(bookDB.getBid());
			historyDB.setBookName(bookDB.getBookName());
			// ✅ 修复：借阅时也用LocalDateTime，和实体类一致，彻底杜绝类型问题
			historyDB.setBeginTime(LocalDateTime.now());
			// 借阅有效期：当前时间 + 用户可借阅天数，这里直接写死7天，兼容你的DateUtils
			historyDB.setEndTime(LocalDateTime.now().plusDays(userDB.getLendNum()));
			historyDB.setStatus(1);
			historyDao.addHistory(historyDB, conn);
			
			Integer num = bookDB.getNum();
			if (num <= 0) {
				throw new MyException("库存不足");
			}
			bookDB.setNum(--num);
			bookDB.setTimes(bookDB.getTimes() + 1);
			bookDao.changeNum(bookDB,conn);
			
			userDB.setTimes(userDB.getTimes() + 1);
			if (userDB.getMaxNum() <= 0) {
				throw new MyException("借阅次数已满");
			}
			userDB.setMaxNum(userDB.getMaxNum() - 1);
			userDao.updNum(userDB,conn);
			conn.commit();
		} catch (Exception e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			if (e instanceof MyException) {
				throw new MyException(e.getMessage());
			} else {
				e.printStackTrace();
				throw new MyException("借阅失败");
			}
		}
	}
	
	/**
	 * 图书归还 【终极完整版：修复所有BUG + 打印真实报错日志】
	 * @param hid
	 */
	public void backBook(String hid) {
		Connection conn = C3p0Tool.getConnection();
		try {
			conn.setAutoCommit(false);
			System.out.println("=======开始执行还书逻辑，hid="+hid+"=======");
			// 1. 查询借阅记录
			HistoryDB historyDB = historyDao.list(hid).get(0);
			System.out.println("查询到借阅记录："+historyDB);
			historyDB.setStatus(2);
			historyDB.setEndTime(LocalDateTime.now()); //归还时间为当前时间
			historyDao.updHistory(historyDB, conn);
			System.out.println("1. 修改借阅记录状态为已归还，成功！");
			
			// 2. 修改图书库存
			Integer bid = historyDB.getBid();
			BookDB bookDB = bookDao.list(null, bid+"").get(0);
			System.out.println("查询到图书信息："+bookDB);
			bookDB.setNum(bookDB.getNum() + 1);
			bookDao.changeNum(bookDB, conn);
			System.out.println("2. 图书库存+1，成功！");
			
			// 3. 修改用户可借阅数量
			Integer uid = historyDB.getUid();
			UserDB userDB = new UserDB();
			userDB.setUid(uid);
			userDB = userDao.getList(userDB).get(0);
			System.out.println("查询到用户信息："+userDB);
			userDB.setMaxNum(userDB.getMaxNum() + 1);
			userDao.updNum(userDB, conn);
			System.out.println("3. 用户可借阅数+1，成功！");
			
			conn.commit();
			System.out.println("=======还书逻辑执行完毕，事务提交成功！=======");
		} catch (Exception e) {
			// ✅ 核心修改：打印真实的报错信息+报错行号，再也不会隐藏问题！
			e.printStackTrace();
			System.err.println("=======还书失败的真实原因："+e.getMessage()+"=======");
			try {
				conn.rollback();
				System.out.println("事务回滚成功");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			if (e instanceof MyException) {
				throw new MyException(e.getMessage());
			} else {
				// 这里可以先注释掉，直接看控制台的真实报错
				throw new MyException("还书失败，真实原因："+e.getMessage());
			}
		}
	}
}