package com.sxt.web.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sxt.entity.HistoryDB;
import com.sxt.entity.UserDB;
import com.sxt.service.HistoryService;
import com.sxt.utils.PageTool;
import com.sxt.utils.PaginationUtils;

/**
 * 图书借阅/归还记录 Servlet - 恢复【管理员/普通用户 数据隔离】核心权限逻辑
 * 规则：管理员看全部，普通用户看自己
 */
@WebServlet("/history")
public class HistoryServlet extends BaseServlet {

	private static final long serialVersionUID = 1L;
	
	private HistoryService historyService = new HistoryService();

	/**
	 * 查询【正在借阅】记录 - 带权限过滤
	 */
	public void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ============ 核心恢复：从session获取当前登录的用户对象 ============
		UserDB loginUser = (UserDB) request.getSession().getAttribute("userDB");
		Integer uid = null; // 默认null=查询所有人（管理员权限）
		
		// ============ 权限判断核心逻辑 ============
		if(loginUser != null){
			// 1. 如果是【普通用户】 (role=1 是普通用户，根据你数据库的角色值定，一般是1)
			if(loginUser.getRole() == 1){
				uid = loginUser.getUid(); // 只查询【自己】的借阅记录
			}
			// 2. 如果是【管理员】 (role=0 或 role=2，管理员权限)，uid=null 查所有人
		}
		
		String currentPage = request.getParameter("pageNum");
		String pageSize = request.getParameter("pageSize");
		// 传递参数：uid(用户ID过滤) + status=1(正在借阅)
		PageTool<HistoryDB> pageTool = historyService.listByPage(currentPage, pageSize, uid, 1);
		
		String path = "history?method=list";
		String pagation = PaginationUtils.getPagation(pageTool.getTotalCount(), pageTool.getCurrentPage(), pageTool.getPageSize(), path);
		request.setAttribute("pagation", pagation);
		request.setAttribute("hList", pageTool.getRows());
		
		// ============ 页面跳转也分权限（和你原项目一致） ============
		if(loginUser != null && loginUser.getRole() == 1){
			// 普通用户 → 跳转到【用户自己的借阅页面】 borrow.jsp
			request.getRequestDispatcher("user/borrow.jsp").forward(request, response);
		}else{
			// 管理员 → 跳转到【管理员的借阅页面】 admin_borrow.jsp
			request.getRequestDispatcher("admin/admin_borrow.jsp").forward(request, response);
		}
	}
	
	/**
	 * 查询【已归还】记录 - 带权限过滤
	 */
	public void backList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ============ 核心恢复：从session获取当前登录的用户对象 ============
		UserDB loginUser = (UserDB) request.getSession().getAttribute("userDB");
		Integer uid = null; // 默认null=查询所有人（管理员权限）
		
		// ============ 权限判断核心逻辑 ============
		if(loginUser != null){
			if(loginUser.getRole() == 1){
				uid = loginUser.getUid(); // 普通用户只查自己的归还记录
			}
		}
		
		String currentPage = request.getParameter("pageNum");
		String pageSize = request.getParameter("pageSize");
		// 传递参数：uid(用户ID过滤) + status=2(已归还)
		PageTool<HistoryDB> pageTool = historyService.listByPage(currentPage, pageSize, uid, 2);
		
		String path = "history?method=backList";
		String pagation = PaginationUtils.getPagation(pageTool.getTotalCount(), pageTool.getCurrentPage(), pageTool.getPageSize(), path);
		request.setAttribute("pagation", pagation);
		request.setAttribute("hList", pageTool.getRows());
		
		// ============ 页面跳转分权限 ============
		if(loginUser != null && loginUser.getRole() == 1){
			// 普通用户 → 跳转到【用户自己的归还页面】 history.jsp
			request.getRequestDispatcher("user/history.jsp").forward(request, response);
		}else{
			// 管理员 → 跳转到【管理员的归还页面】 admin_history.jsp
			request.getRequestDispatcher("admin/admin_history.jsp").forward(request, response);
		}
	}
	
	/**
	 * 图书延期功能 - 不变
	 */
	public void delay(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
		String hid = request.getParameter("hid");
		String endtime = request.getParameter("endtime");
		HistoryDB historyDB = new HistoryDB();
		historyDB.setHid(Integer.parseInt(hid));
		historyDB.setEndTime(LocalDateTime.parse(endtime));
		historyService.updHistory(historyDB);
		response.sendRedirect(request.getContextPath()+"/history?method=list");
	}
}