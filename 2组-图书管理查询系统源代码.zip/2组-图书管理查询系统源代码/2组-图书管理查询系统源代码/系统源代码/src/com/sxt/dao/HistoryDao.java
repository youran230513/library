package com.sxt.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.BasicRowProcessor;
import org.apache.commons.dbutils.BeanProcessor;
import org.apache.commons.dbutils.GenerousBeanProcessor;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.RowProcessor;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.sxt.entity.BookDB;
import com.sxt.entity.HistoryDB;
import com.sxt.utils.C3p0Tool;
import com.sxt.utils.PageTool;

public class HistoryDao {
	
	QueryRunner queryRunner = new QueryRunner(C3p0Tool.getDataSource());
	//开启驼峰自动转换
	BeanProcessor bean = new GenerousBeanProcessor();
	RowProcessor processor = new BasicRowProcessor(bean);

	/**
	 * 添加图书借阅记录
	 * @return
	 * @throws SQLException 
	 */
	public Integer addHistory(HistoryDB historyDB, Connection conn) throws SQLException {
		QueryRunner queryRunner = new QueryRunner();
		String sql = "insert into t_history (uid,name,account,bid,book_name,begin_time, end_time,status) values (?,?,?,?,?,?,?,?)";
		Object[] params = {historyDB.getUid(),historyDB.getName(),historyDB.getAccount(),historyDB.getBid(),
				historyDB.getBookName(),historyDB.getBeginTime(),historyDB.getEndTime(),historyDB.getStatus()};
		return queryRunner.update(conn, sql, params);
	}

	/**
	 * 查询图书借阅记录
	 * @param currentPage
	 * @param pageSize
	 * @param uid
	 * @param status
	 * @return
	 */
	public PageTool<HistoryDB> listByPage(String currentPage, String pageSize, Integer uid, Integer status){
		try {
			
	        int currPage = 1;
	        int pageSz = 10;
	        if(currentPage != null && !"".equals(currentPage) && currentPage.matches("\\d+")){
	            currPage = Integer.parseInt(currentPage);
	        }
	        if(pageSize != null && !"".equals(pageSize) && pageSize.matches("\\d+")){
	            pageSz = Integer.parseInt(pageSize);
	        }
	        
			// 关键修复：指定字段名，数据库字段名 对应 实体类属性名，放弃驼峰转换，百分百封装成功！
			StringBuffer listSql = new StringBuffer("select hid,uid,name,account,bid,book_name as bookName,begin_time as beginTime,end_time as endTime,status");
			StringBuffer countSql = new StringBuffer("select count(*)");
			StringBuffer sql = new StringBuffer(" from t_history where 1 = 1");
			List<Object> params = new ArrayList<>();
			if (uid != null) {
				sql.append(" and uid = ?");
				params.add(uid);
			}
			if (status != null) {
				sql.append(" and status = ?");
				params.add(status);
			}
			// ============ 修改点1：单独拼接统计总数的SQL ============
			Long total = queryRunner.query("select count(*)".concat(sql.toString()), new ScalarHandler<Long>(),params.toArray());
			//初始化分页工具
			PageTool<HistoryDB> pageTools = new PageTool<HistoryDB>(total.intValue(), currentPage, pageSize);
			sql.append(" order by begin_time desc limit ?,?");
			
			// ============ 修改点2：新建分页参数集合，分离参数 ============
			List<Object> pageParams = new ArrayList<>(params);
			pageParams.add(pageTools.getStartIndex());
			pageParams.add(pageTools.getPageSize());
			
			//当前页的数据		
			 List<HistoryDB> list = queryRunner.query(listSql.append(sql).toString(), new BeanListHandler<HistoryDB>(HistoryDB.class, processor),pageParams.toArray());
			 pageTools.setRows(list);
			 
			// ============ 新增：打印日志，看控制台输出 ============
			 System.out.println("执行的SQL语句：" + listSql.append(sql).toString());
			 System.out.println("Dao层查询到的数据条数：" + list.size());
			 System.out.println(pageTools);
			 return pageTools;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return new PageTool<HistoryDB>(0, currentPage, pageSize);
	}
	
	/**
	 * 无分页·查询
	 * @param hid
	 * @return
	 */
//	public List<HistoryDB> list(String hid){
//		StringBuffer sql = new StringBuffer("select * from t_history where 1 = 1 ");
//		List<Object> params = new ArrayList<>();
//		if (hid != null && hid != "") {
//			sql.append("and hid = ?");
//			params.add(hid);
//		}
//		try {
//			return queryRunner.query(sql.toString(), new BeanListHandler<HistoryDB>(HistoryDB.class, processor), params.toArray());
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		return null;
//	}
	/**
	 * 根据借阅记录ID(hid)查询单条记录
	 * @param hid 借阅记录主键
	 * @return
	 */
	public List<HistoryDB> list(String hid) {
		String sql = "select * from t_history where hid=?"; // 必须是 hid=?
		return C3p0Tool.query(sql, new HistoryDB(), hid);
	}
	
	/**
	 * 修改图书借阅历史记录
	 * @param historyDB
	 * @param conn
	 * @return
	 * @throws SQLException
	 */
	public Integer updHistory(HistoryDB historyDB,  Connection conn) throws SQLException {
		QueryRunner qr = new QueryRunner();
		String sql = "update t_history set status = ? where hid = ?";
		Object[] params = {historyDB.getStatus(), historyDB.getHid()};
		return qr.update(conn, sql, params);
	}
	
	public Integer updHistory(HistoryDB historyDB) throws SQLException {
		String sql = "update t_history set end_time = ? where hid = ?";
		Object[] params = {historyDB.getEndTime(), historyDB.getHid()};
		return queryRunner.update(sql, params);
	}
}