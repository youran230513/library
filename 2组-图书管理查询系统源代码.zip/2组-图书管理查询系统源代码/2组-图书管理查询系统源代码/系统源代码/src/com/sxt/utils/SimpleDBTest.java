package com.sxt.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

public class SimpleDBTest {
    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        try {
            // Use SQLite for simple testing (no need for server setup)
            String url = "jdbc:sqlite:test.db";
            conn = DriverManager.getConnection(url);
            
            System.out.println("Successfully connected to database!");
            
            // Create a test table
            stmt = conn.createStatement();
            String createTable = "CREATE TABLE IF NOT EXISTS test_users (id INTEGER PRIMARY KEY, name TEXT)";
            stmt.execute(createTable);
            System.out.println("Test table created successfully");
            
            // Insert test data
            stmt.execute("INSERT OR IGNORE INTO test_users (id, name) VALUES (1, 'Test User')");
            
            // Query data
            rs = stmt.executeQuery("SELECT * FROM test_users");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") + ", Name: " + rs.getString("name"));
            }
            
            System.out.println("Database operations completed successfully!");
            
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}